import EclipseWidget from './EclipseWidget';

export default EclipseWidget;